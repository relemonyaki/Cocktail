package com.example.CocktailDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CocktailDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
