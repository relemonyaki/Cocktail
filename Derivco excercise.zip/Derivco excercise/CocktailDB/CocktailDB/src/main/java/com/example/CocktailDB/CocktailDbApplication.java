package com.example.CocktailDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CocktailDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CocktailDbApplication.class, args);
	}

}
