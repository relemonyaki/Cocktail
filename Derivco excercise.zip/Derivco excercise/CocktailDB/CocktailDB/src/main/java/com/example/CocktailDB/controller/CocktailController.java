package com.example.CocktailDB.controller;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Properties;

@RestController
public class CocktailController {
    WebDriver driver;
    Properties properties;
    String path = "src/main/resources/chromedriver.exe";

    @FindBy(name = "s")
    private WebElement searchBox;

    @FindBy(xpath = "//*[@id=\"feature\"]/div[1]/div/table[2]/tbody/tr/td/form/div/div/button")
    private WebElement searchBtn;

    @FindBy(xpath = "//*[@id=\"feature\"]/div/div")
    private WebElement page;

    @RequestMapping("/hello")
    public String hello(){
        return "Hello World!";
    }

    @GetMapping(value = "/cocktails", produces = "/application.json")
    private String getCocktails() {
        System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        properties = loadProperties(path);
        driver.get(properties.getProperty("url"));

        this.searchBox.sendKeys(properties.getProperty("cocktailToSearch"));
        this.searchBtn.click();
        String body = driver.findElement(By.xpath("//*[@id=\"feature\"]/div/div")).getText();

        if(body.contains("No drinks found")){

        }


        String uri = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s=margarita";
        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.getForObject(uri, String.class);
        return result;
    }

    public Properties loadProperties(String path){
        try {
            properties = new Properties();
            properties.load(CocktailController.class.getClassLoader().getResourceAsStream(path));
        }catch (Exception e){
            e.printStackTrace();
        }
        return properties;
    }
}
